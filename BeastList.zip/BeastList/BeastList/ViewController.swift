//
//  ViewController.swift
//  BeastList
//
//  Created by Conner on 2/2/19.
//  Copyright © 2019 damianserrato. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var textField: UITextField!
    @IBOutlet weak var beastButton: UIButton!
    @IBOutlet weak var tableView: UITableView!
    
    @IBAction func beastButtonPressed(_ sender: UIButton) {
        let str1 = textField.text
        
        tasks.append(str1!)
        tableView.reloadData()
    }
    
    var tasks = ["Something Cool", "Something vERy cool", "Something EXTREMELY cool"]
    
    
    
        override func viewDidLoad() {
            super.viewDidLoad()
            tableView.dataSource = self
            tableView.reloadData()
        }
    
        override func didReceiveMemoryWarning() {
            super.didReceiveMemoryWarning()
        }
    
    
    }

    extension ViewController: UITableViewDataSource {
        func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
            return tasks.count
        }
        func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
    
            let cell = tableView.dequeueReusableCell(withIdentifier: "myCell", for: indexPath)
            cell.textLabel?.text = tasks[indexPath.row]
            return cell
    
        }


}


